Unifying class that represents Genome
=====================================
  
.. automodule:: mirnylib.genome 
    :members:
