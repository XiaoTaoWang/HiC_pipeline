Iterative mapping 
=================
  
.. automodule:: hiclib.mapping
    :members:
