Fragment-level HiC correction
=============================
  
.. automodule:: hiclib.fragmentHiC
    :members:
