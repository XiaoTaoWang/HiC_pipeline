Analysis of binned data
=======================
  
.. automodule:: hiclib.binnedData 
    :members:
