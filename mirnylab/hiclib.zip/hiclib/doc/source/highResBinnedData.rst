High-resolution analysis of binned data
=======================================
  
.. automodule:: hiclib.highResBinnedData 
    :members:
