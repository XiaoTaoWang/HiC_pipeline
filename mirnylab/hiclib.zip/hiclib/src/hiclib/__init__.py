import inspect, os

hiclibfolder = os.path.dirname(os.path.abspath(
            os.path.join(inspect.getfile(inspect.currentframe()),
                         '../../')))

