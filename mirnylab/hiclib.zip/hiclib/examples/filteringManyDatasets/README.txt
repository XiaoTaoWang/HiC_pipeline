Note: a new version of mergeDataset from 2013 is provided. 
It uses slightly different format. 

This is a script that was used to merged multiple datasets, perform fragment-level filtering and save heatmaps. 

The scripts inputs data from datasets.tsv file, and outputs heatmaps at different resolution.
It also saves heatmaps, derived from random breaks only. 

This script was used to merge data from the (Dixon, Nature 2012) publication. 
