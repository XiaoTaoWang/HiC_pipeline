#!/bin/bash
#This just re-runs buildTable to accomodate the new stuff
python 004_buildTable.py