echo "Download the data..."
mkdir -p data/sample
cd data/sample

wget ftp://ftp-trace.ncbi.nlm.nih.gov/sra/sra-instant/reads/ByStudy/sra/SRP%2FSRP001%2FSRP001261/SRR027956/SRR027956.sra -O SRR027956.sra

