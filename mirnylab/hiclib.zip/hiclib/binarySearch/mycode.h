#ifndef __MYCODE_H__
#define __MYCODE_H__
#include <cstdint>
void int64BinarySearch(uint64_t* data, long int N, uint64_t* keys, long int M, int32_t* result, uint64_t mult);
//void uint64BinarySearch(uint64_t* data, long int N, uint64_t* keys, long int M, int32_t* result, uint64_t multiplyer)
#endif


