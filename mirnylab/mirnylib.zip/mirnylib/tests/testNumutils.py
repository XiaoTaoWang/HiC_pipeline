from mirnylib import numutils
numutils._test()
