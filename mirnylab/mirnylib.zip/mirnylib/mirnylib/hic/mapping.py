'''
mapping - map raw Hi-C reads to a genome
'''
import warnings
warnings.warn("\nMirnylab.hic.mapping was moved to hiclib.mapping\nuse that instead!", stacklevel=2)
from hiclib.mapping import *
